export interface LightChecklist {
    id: number;
    name: string;
    checked: boolean;
  }
  