export interface Bullet {
    _id?: string;
    description: string;
    code: string;
    section: string; // sectionId
    requerido: Boolean;
  }